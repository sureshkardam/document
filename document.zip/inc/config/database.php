<? if ( ! defined('BASEDIR')) exit('Acces denied');
/*
|-------------------------------------------------------------------
| DATABASE CONSTANTS
|-------------------------------------------------------------------
| This file contains database connectivity details
| 
|-------------------------------------------------------------------
| VARIABLE LIST
|-------------------------------------------------------------------
|
|	['DB_HOST'] The hostname of your database server.
|	['DB_USER'] The username used to connect to your server
|	['DB_PASS'] The password used to connect to your server
|	['DB_NAME'] The database you wish to select from your server
|
*/
// VARIABLES

define('DB_HOST', "localhost");
define('DB_USER', "root");
define('DB_PASS', "");
define('DB_NAME', "document");
?>